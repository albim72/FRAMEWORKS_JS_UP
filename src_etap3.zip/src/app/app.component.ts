import { Component } from '@angular/core';
import {Todo} from './todo';
import {TodosService} from "./todos.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ListaZadan';
  public todos: Todo[];
  constructor(private todoService:TodosService) {
    this.todos = todoService.getTodos();
  }
  public addTodo(todo:Todo){
    this.todos.unshift(todo);
  }
  public removerTodo(todo:Todo){
    this.todos = this.todos.filter(item=>item!=todo);
  }
}
