import {Injectable} from "@angular/core";
import {Todo} from "./todo";
import {TodoStatus} from "./todo-status.enum";

@Injectable()
export class TodosService {
  getTodos():Todo[] {
    return [
      {name:'zadanie otwarcia',status: TodoStatus.BUG},
      {name:'zadanie kluczowe', status:TodoStatus.TODO},
      {name:'zadanie ostateczne',status:TodoStatus.IN_REVIEW}
    ];
  }
}
